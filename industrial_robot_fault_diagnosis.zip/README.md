
# Industrial Robot Arm Fault Diagnosis (Python Simulation)

This project simulates actuator and sensor faults for a 6-DOF industrial robot arm, extracts time and frequency domain features, and trains machine learning classifiers for fault diagnosis.

## Folder Structure

- simulation/: Actuator, Sensor, Robot models
- feature_extraction/: Feature extraction scripts
- ml_model/: Model training, evaluation, and analysis
- dataset/: Raw and processed datasets
- results/: Output plots and reports

## Run Workflow

1. Generate Data: `python logging_simulation.py`
2. Extract Features: `python feature_extraction/extract_features.py`
3. Train Model: `python ml_model/train_model.py`
4. Evaluate Model: `python ml_model/evaluate_model.py`

---
